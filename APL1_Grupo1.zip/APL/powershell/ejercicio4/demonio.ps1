#!/usr/bin/env pwsh

#-------------------------------------------------------#
#               Virtualizacion de Hardware              #
#                                                       #
#   APL1                                                #
#   Nro ejercicio: 4                                    #
#                                                       #
#   Integrantes:                                        #
#       Vignardel Francisco                             #
#       De Titto Lucia                                  #
#       Gallardo Samuel                                 #
#       Francisco Vladimir                              #
#       Medina Ramiro                                   #
#                                                       #
#-------------------------------------------------------#

<#
.SYNOPSIS
    Demonio que monitorea un directorio y detecta archivos con palabras clave.

.DESCRIPTION
    Ejecuta un proceso en segundo plano que vigila un directorio usando FileSystemWatcher.
    Cada vez que se crea o modifica un archivo, busca palabras clave dentro de él y registra
    las coincidencias en un archivo de log con fecha, operación y tamaño.
    El demonio puede detenerse ejecutando el script nuevamente con el flag -Kill.

.PARAMETER Directorio
    Ruta del directorio a monitorear. Acepta rutas relativas y absolutas.

.PARAMETER Palabras
    Palabras clave separadas por coma a buscar dentro de los archivos. Ej: password,token,api_key

.PARAMETER Log
    Ruta del archivo de log donde se registran las coincidencias encontradas. Opcional: si no se indica, se crea log.txt en el directorio actual. Si ya existe, se usa log1.txt, log2.txt, etc.

.PARAMETER Kill
    Detiene el demonio activo para el directorio indicado. Solo se usa junto con -Directorio.

.EXAMPLE
    mkdir descargas
    .\demonio.ps1 -Directorio descargas -Palabras "password,token,api_key" -Log monitoreo.log
    "mi password es 1234" | Out-File descargas/credenciales.txt
    Get-Content monitoreo.log
    .\demonio.ps1 -Directorio descargas -Kill
#>

[CmdletBinding(DefaultParameterSetName = 'Iniciar')]
param(
    [Parameter(Mandatory = $true, ParameterSetName = 'Iniciar')]
    [Parameter(Mandatory = $true, ParameterSetName = 'Matar')]
    [ValidateScript({
        if (-not (Test-Path $_ -PathType Container)) {
            throw "El directorio '$_' no existe."
        }
        $true
    })]
    [string]$Directorio,

    [Parameter(Mandatory = $true, ParameterSetName = 'Iniciar')]
    [Alias("p")]
    [string]$Palabras,

    [Parameter(Mandatory = $false, ParameterSetName = 'Iniciar')]
    [Alias("l")]
    [string]$Log = '',

    [Parameter(Mandatory = $true, ParameterSetName = 'Matar')]
    [Alias("k")]
    [switch]$Kill,

    # Variable interna: el proceso padre la pasa al hijo para que sepa que ya es el daemon
    [Parameter(DontShow)]
    [switch]$ModoDemonio
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Capturar la ruta del script aquí (dentro de funciones $PSCommandPath puede variar)
$rutaScript = $PSCommandPath

function registrar_error { param([string]$mensaje) Write-Host "[ERROR] $mensaje" -ForegroundColor Red }
function registrar_info  { param([string]$mensaje) Write-Host "[INFO]  $mensaje" -ForegroundColor Green }
function registrar_aviso { param([string]$mensaje) Write-Host "[AVISO] $mensaje" -ForegroundColor Yellow }
function marca_tiempo    { (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') }

# Convierte una ruta relativa en absoluta
function ruta_absoluta {
    param([string]$ruta)
    if ([string]::IsNullOrWhiteSpace($ruta)) { return '' }
    return [IO.Path]::GetFullPath($ruta)
}

# Genera la ruta única del archivo PID para este directorio (hash evita colisiones entre directorios)
function ruta_archivo_pid {
    param([string]$rutaDirectorio)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($rutaDirectorio)
    $hash  = [System.Security.Cryptography.MD5]::Create().ComputeHash($bytes)
    $hashStr = ($hash | ForEach-Object { $_.ToString('x2') }) -join ''
    return [IO.Path]::Combine([IO.Path]::GetTempPath(), "demonio_$hashStr.pid")
}

function ruta_archivo_estado {
    param([string]$rutaDirectorio)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($rutaDirectorio)
    $hash  = [System.Security.Cryptography.MD5]::Create().ComputeHash($bytes)
    $hashStr = ($hash | ForEach-Object { $_.ToString('x2') }) -join ''
    return [IO.Path]::Combine([IO.Path]::GetTempPath(), "demonio_$hashStr.state")
}

# Genera un nombre de log disponible en el directorio actual: log.txt, log1.txt, log2.txt, ...
function generar_nombre_log {
    $dir = (Get-Location).Path
    $candidato = Join-Path $dir 'log.txt'
    if (-not (Test-Path $candidato)) { return $candidato }
    $i = 1
    while (Test-Path (Join-Path $dir "log${i}.txt")) { $i++ }
    return Join-Path $dir "log${i}.txt"
}

# Verifica si el daemon está corriendo: devuelve su PID o $null si no existe
function pid_del_daemon_activo {
    param([string]$rutaDirectorio)
    $archivoPid = ruta_archivo_pid $rutaDirectorio
    if (-not (Test-Path $archivoPid)) { return $null }  # no existe el archivo PID → no hay daemon
    $pidGuardado = (Get-Content $archivoPid -Raw).Trim()
    try {
        Get-Process -Id $pidGuardado -ErrorAction Stop | Out-Null
        return $pidGuardado  # el proceso sigue vivo → devuelve su PID
    } catch {
        Remove-Item $archivoPid -Force -ErrorAction SilentlyContinue  # el proceso ya no existe → limpia el archivo PID
        return $null
    }
}

# Verifica si el log ya está siendo usado por otro demonio activo
function verificar_log_disponible {
    param([string]$rutaLog)
    $registry = [IO.Path]::Combine([IO.Path]::GetTempPath(), 'demonio_logs.registry')
    if (-not (Test-Path $registry)) { return }
    foreach ($linea in (Get-Content $registry -ErrorAction SilentlyContinue)) {
        $partes = $linea -split '\|', 2
        if ($partes.Count -ne 2) { continue }
        $pidReg = $partes[0].Trim()
        $logReg = $partes[1].Trim()
        if ([string]::IsNullOrWhiteSpace($pidReg) -or [string]::IsNullOrWhiteSpace($logReg)) { continue }
        try { Get-Process -Id $pidReg -ErrorAction Stop | Out-Null } catch { continue }  # proceso ya no existe
        if ($logReg -eq $rutaLog) {
            registrar_error "El archivo de log '$rutaLog' ya está en uso por otro demonio (PID: $pidReg)."
            registrar_error "Cambiá el nombre o la ruta del log con -Log."
            exit 1
        }
    }
}

function registrar_log_en_uso {
    param([string]$pidDemonio, [string]$rutaLog)
    $registry = [IO.Path]::Combine([IO.Path]::GetTempPath(), 'demonio_logs.registry')
    Add-Content -LiteralPath $registry -Value "$pidDemonio|$rutaLog" -Encoding ascii
}

function liberar_log_en_uso {
    param([string]$pidDemonio)
    $registry = [IO.Path]::Combine([IO.Path]::GetTempPath(), 'demonio_logs.registry')
    if (-not (Test-Path $registry)) { return }
    $lineas = Get-Content $registry -ErrorAction SilentlyContinue | Where-Object { $_ -notmatch "^${pidDemonio}\|" }
    if ($null -eq $lineas) { $lineas = @() }
    $lineas | Set-Content -LiteralPath $registry -Encoding ascii
}

# Log
function escribir_linea_log {
    param([string]$linea, [string]$rutaLog)
    Add-Content -LiteralPath $rutaLog -Value $linea -Encoding UTF8
}

# Inicializa el daemon en segundo plano y guarda su PID para poder matarlo después
function lanzar_daemon {
    param([string]$rutaDirectorio, [string]$palabrasCrudas, [string]$rutaLog)

    # Detectar el ejecutable de PowerShell disponible
    $ejecutablePwsh = Get-Command pwsh -ErrorAction SilentlyContinue
    $ejecutable = if ($ejecutablePwsh) { $ejecutablePwsh.Source } else { 'powershell' }

    $argumentos = @(
        '-NoProfile', '-ExecutionPolicy', 'Bypass',
        '-File', "`"$rutaScript`"",
        '-Directorio', "`"$rutaDirectorio`"",
        '-Palabras', "`"$palabrasCrudas`"",
        '-Log', "`"$rutaLog`"",
        '-ModoDemonio'
    )

    # -FilePath: ejecutable a lanzar (pwsh o powershell)
    # -ArgumentList: argumentos que recibe el proceso hijo
    # -PassThru: devuelve el objeto del proceso para poder leer su PID
    $procesoDemonio    = Start-Process -FilePath $ejecutable -ArgumentList $argumentos -PassThru
    $pidProcesoDemonio = $procesoDemonio.Id

    # Guardar el PID del hijo para poder matarlo después con -Kill
    $pidProcesoDemonio | Out-File -FilePath (ruta_archivo_pid $rutaDirectorio) -Encoding ascii -Force
    registrar_info "Daemon iniciado en segundo plano (PID: $pidProcesoDemonio)."
}

function obtener_tamanio_en_bytes {
    param([string]$rutaArchivo)
    try { return (Get-Item -LiteralPath $rutaArchivo).Length } catch { return '?' }
}

# Verifica si un archivo es binario leyendo sus primeros bytes
function es_archivo_binario {
    param([string]$rutaArchivo)
    try {
        $stream = [IO.File]::Open($rutaArchivo, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
        try {
            $buffer = New-Object byte[] 8192
            $leidos = $stream.Read($buffer, 0, 8192)
            for ($i = 0; $i -lt $leidos; $i++) {
                if ($buffer[$i] -eq 0) { return $true }
            }
            return $false
        } finally { $stream.Dispose() }
    } catch { return $true }
}

# Busca las palabras clave dentro de un archivo y si las encuentra registra la coincidencia en el log
function buscar_palabras_clave_en_archivo {
    param([string]$rutaArchivo, [string]$tipoOperacion, [string[]]$palabrasClave, [string]$rutaLog)
    if (-not (Test-Path $rutaArchivo -PathType Leaf)) { return }
    if (es_archivo_binario $rutaArchivo) { return }  # saltar binarios
    $tamanioBytes = obtener_tamanio_en_bytes $rutaArchivo
    try {
        $contenido = Get-Content -LiteralPath $rutaArchivo -Raw -ErrorAction Stop
    } catch { return }
    foreach ($palabraClave in $palabrasClave) {
        if ([string]::IsNullOrWhiteSpace($palabraClave)) { continue }
        # -match sin distinción de mayúsculas/minúsculas (comportamiento por defecto en PowerShell)
        if ($contenido -match [regex]::Escape($palabraClave)) {
            $linea = "[{0}] Operación: {1,-10} | Archivo: '{2}' | Palabra: '{3}' | Tamaño: {4} bytes" -f `
                (marca_tiempo), $tipoOperacion, $rutaArchivo, $palabraClave, $tamanioBytes
            escribir_linea_log $linea $rutaLog
        }
    }
}

# Escanea los archivos que ya estaban en el directorio al momento de iniciar el daemon
function escanear_archivos_preexistentes {
    param([string]$rutaDirectorio, [string[]]$palabrasClave, [string]$rutaLog)
    $archivoEstado = ruta_archivo_estado $rutaDirectorio
    $hayEstado = Test-Path $archivoEstado
    $ultimaEjecucion = if ($hayEstado) {
        [datetime]::Parse((Get-Content $archivoEstado -Raw).Trim())
    } else { $null }
    $cantidadArchivos = 0
    escribir_linea_log ("[{0}] Procesando archivos existentes en '{1}' ..." -f (marca_tiempo), $rutaDirectorio) $rutaLog
    Get-ChildItem -LiteralPath $rutaDirectorio -File -ErrorAction SilentlyContinue |
        Where-Object { -not $hayEstado -or $_.LastWriteTime -gt $ultimaEjecucion } |
        ForEach-Object {
            buscar_palabras_clave_en_archivo $_.FullName 'EXISTENTE' $palabrasClave $rutaLog
            $cantidadArchivos++
        }
    escribir_linea_log ("[{0}] {1} archivos existentes procesados." -f (marca_tiempo), $cantidadArchivos) $rutaLog
}

# Bucle infinito que espera eventos de FileSystemWatcher y los procesa uno a uno
function iniciar_bucle_de_monitoreo {
    param([string]$rutaDirectorio, [string[]]$palabrasClave, [string]$rutaLog)

    escribir_linea_log ("[{0}] Demonio iniciado | Directorio: '{1}' | Palabras: {2}" -f `
        (marca_tiempo), $rutaDirectorio, ($palabrasClave -join ', ')) $rutaLog

    escanear_archivos_preexistentes $rutaDirectorio $palabrasClave $rutaLog
    # Guardar el timestamp del escaneo inicial para que un reinicio no reprocese estos archivos
    (Get-Date).ToString('o') | Out-File -FilePath (ruta_archivo_estado $rutaDirectorio) -Encoding ascii -Force

    # FileSystemWatcher es el equivalente a inotifywait en PowerShell
    $watcher = New-Object IO.FileSystemWatcher
    $watcher.Path                  = $rutaDirectorio
    $watcher.IncludeSubdirectories = $false
    $watcher.EnableRaisingEvents   = $true

    $archivoPid = ruta_archivo_pid $rutaDirectorio

    # Espera eventos indefinidamente hasta que se elimine el archivo PID (señal de kill)
    while (Test-Path $archivoPid) {
        # WaitForChanged bloquea hasta detectar un cambio o hasta que se cumpla el timeout (1 segundo)
        $evento = $watcher.WaitForChanged([IO.WatcherChangeTypes]::All, 1000)
        if ($evento.TimedOut) { continue }
        $rutaArchivo    = Join-Path $rutaDirectorio $evento.Name
        $tipoOperacion  = $evento.ChangeType.ToString().ToUpper()
        buscar_palabras_clave_en_archivo $rutaArchivo $tipoOperacion $palabrasClave $rutaLog
        # Actualizar el estado tras cada evento procesado
        (Get-Date).ToString('o') | Out-File -FilePath (ruta_archivo_estado $rutaDirectorio) -Encoding ascii -Force
    }

    $watcher.EnableRaisingEvents = $false
    $watcher.Dispose()
    escribir_linea_log ("[{0}] Demonio detenido." -f (marca_tiempo)) $rutaLog
}

# Matar Demonio
function detener_daemon {
    param([string]$rutaDirectorio)
    $pidActivo = pid_del_daemon_activo $rutaDirectorio
    if ($null -eq $pidActivo) {
        registrar_aviso "No hay daemon corriendo para '$rutaDirectorio'."
        exit 1
    }
    try {
        Stop-Process -Id $pidActivo -Force -ErrorAction Stop
        Remove-Item (ruta_archivo_pid    $rutaDirectorio) -Force -ErrorAction SilentlyContinue
        Remove-Item (ruta_archivo_estado $rutaDirectorio) -Force -ErrorAction SilentlyContinue
        registrar_info "Daemon detenido (PID: $pidActivo)."
    } catch {
        registrar_error "No se pudo detener el proceso (PID: $pidActivo): $_"
        exit 1
    }
}

# Convertir rutas a absolutas (param ya validó que el directorio existe)
$Directorio = ruta_absoluta $Directorio

# Modo kill: detener el daemon
if ($Kill) {
    detener_daemon $Directorio
    exit 0
}

$archivoLog = if (-not [string]::IsNullOrWhiteSpace($Log)) { ruta_absoluta $Log } else { '' }

# Modo daemon (hijo relanzado): variable interna que indica que ya es el proceso en segundo plano
if ($ModoDemonio) {
    # El hijo recibe las palabras como string separado por coma
    $palabrasClave = ($Palabras -join ',') -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }
    $pidActual = $PID.ToString()
    registrar_log_en_uso $pidActual $archivoLog
    try {
        iniciar_bucle_de_monitoreo $Directorio $palabrasClave $archivoLog
    } finally {
        liberar_log_en_uso $pidActual
        Remove-Item (ruta_archivo_pid    $Directorio) -Force -ErrorAction SilentlyContinue
        Remove-Item (ruta_archivo_estado $Directorio) -Force -ErrorAction SilentlyContinue
    }
    exit 0
}

# Normalizar el array de palabras clave
$palabrasClave = ($Palabras -join ',') -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }

# Prevenir demonios duplicados para el mismo directorio
$pidExistente = pid_del_daemon_activo $Directorio
if ($null -ne $pidExistente) {
    registrar_error "Ya hay un daemon para este directorio (PID: $pidExistente)."
    exit 1
}

# Si no se especificó -Log, generar nombre automáticamente en el directorio actual
if ([string]::IsNullOrWhiteSpace($archivoLog)) {
    $archivoLog = generar_nombre_log
    registrar_info "Archivo de log generado automáticamente: $archivoLog"
}

# Prevenir que dos demonios usen el mismo archivo de log
verificar_log_disponible $archivoLog

# Crear el directorio del log si no existe, y el archivo log vacío
$dirLog = Split-Path $archivoLog -Parent
if ($dirLog -and -not (Test-Path $dirLog)) {
    New-Item -ItemType Directory -Path $dirLog -Force | Out-Null
}
try {
    [IO.File]::WriteAllText($archivoLog, '')
} catch {
    registrar_error "No puedo escribir en '$archivoLog'."
    exit 1
}

# Lanzar el daemon en segundo plano y guardar su PID
lanzar_daemon $Directorio ($palabrasClave -join ',') $archivoLog
