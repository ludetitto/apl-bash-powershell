#!/usr/bin/env pwsh

#-------------------------------------------------------#
#               Virtualizacion de Hardware              #
#                                                       #
#   APL1                                                #
#   Nro ejercicio: 3                                    #
#                                                       #
#   Integrantes:                                        #
#       Vignardel Francisco                             #
#       De Titto Lucia                                  #
#       Gallardo Samuel                                 #
#       Francisco Vladimir                              #
#       Medina Ramiro                                   #
#                                                       #
#-------------------------------------------------------#

<#
.SYNOPSIS
    Detecta archivos duplicados en un directorio y sus subdirectorios.

.DESCRIPTION
    El script busca archivos que tengan el mismo nombre y tamanio dentro
    de un directorio dado, incluyendo todos sus subdirectorios, y muestra
    un listado con los duplicados encontrados y sus ubicaciones.

.PARAMETER directorio
    Ruta del directorio a analizar. Puede ser relativa o absoluta.

.EXAMPLE
    .\ejercicio3.ps1 -directorio "C:\Users\Usuario\Documentos"

#>
param(
    [string]$directorio
)

# Si no se paso el parametro lo pedimos manualmente
while ([string]::IsNullOrEmpty($directorio)) {
    $directorio = (Read-Host "Ingrese la ruta del directorio a analizar (sin comillas)").Trim('"').Trim("'")

}

# Validamos que el directorio exista
if (-not (Test-Path $directorio -PathType Container)) {
    Write-Error "El directorio '$directorio' no existe o no es valido."
    exit 1
}

# Validamos permisos de lectura
try {
    Get-ChildItem -Path $directorio -ErrorAction Stop | Out-Null
} catch {
    Write-Error "No tenes permisos de lectura sobre '$directorio'."
    exit 1
}

function BuscarDuplicados {
    $tabla = @{}

    $archivos = Get-ChildItem -Path $directorio -Recurse -File

    foreach ($archivo in $archivos) {
        $clave = "$($archivo.Name):$($archivo.Length)"
        $dir = $archivo.DirectoryName

        if ($tabla.ContainsKey($clave)) {
            $tabla[$clave] += "|$dir"
        } else {
            $tabla[$clave] = $dir
        }
    }

    $hayDuplicados = $false

    foreach ($clave in $tabla.Keys) {
        $directorios = $tabla[$clave]
        $cantidad = ($directorios -split "\|").Count

        if ($cantidad -ge 2) {
            $hayDuplicados = $true
            $nombre = $clave -split ":" | Select-Object -First 1

            Write-Host "archivo: $nombre"
            foreach ($dir in ($directorios -split "\|")) {
                Write-Host "  directorio: $dir"
            }
            Write-Host ""
        }
    }

    if (-not $hayDuplicados) {
        Write-Host "No se encontraron archivos duplicados en '$directorio'."
    }
}

BuscarDuplicados